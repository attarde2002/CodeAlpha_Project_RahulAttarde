const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

mongoose.connect('mongodb://localhost:27017/socialmedia', { useNewUrlParser: true, useUnifiedTopology: true });

const postSchema = new mongoose.Schema({
    content: String
});

const Post = mongoose.model('Post', postSchema);

app.use(bodyParser.json());
app.use(express.static('public'));

app.get('/posts', async (req, res) => {
    const posts = await Post.find();
    res.json({ posts });
});

app.post('/add_post', async (req, res) => {
    const newPost = new Post({ content: req.body.content });
    await newPost.save();
    res.json({ success: true });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
