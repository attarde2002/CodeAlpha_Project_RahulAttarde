document.addEventListener('DOMContentLoaded', () => {
    const postForm = document.getElementById('postForm');
    const postContent = document.getElementById('postContent');
    const postsSection = document.getElementById('posts');

    postForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const content = postContent.value.trim();
        if (content) {
            fetch('/add_post', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ content })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadPosts();
                    postContent.value = '';
                }
            });
        }
    });

    function loadPosts() {
        fetch('/posts')
            .then(response => response.json())
            .then(data => {
                postsSection.innerHTML = '';
                data.posts.forEach(post => {
                    const postDiv = document.createElement('div');
                    postDiv.className = 'post';
                    postDiv.textContent = post.content;
                    postsSection.appendChild(postDiv);
                });
            });
    }

    loadPosts();
});
