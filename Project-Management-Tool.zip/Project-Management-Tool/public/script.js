document.addEventListener('DOMContentLoaded', loadProjects);

function loadProjects() {
  fetch('http://localhost:3000/api/projects')
    .then(response => response.json())
    .then(projects => {
      const projectList = document.getElementById('project-list');
      projectList.innerHTML = '';
      projects.forEach(project => {
        const li = document.createElement('li');
        li.innerHTML = `${project.name} <button onclick="deleteProject('${project.id}')">Delete</button>`;
        projectList.appendChild(li);
      });
    });
}

function addProject() {
  const projectName = document.getElementById('project-name').value;
  const projectId = Math.random().toString(36).substr(2, 9);

  fetch('http://localhost:3000/api/projects', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ id: projectId, name: projectName })
  })
    .then(response => response.json())
    .then(project => {
      const projectList = document.getElementById('project-list');
      const li = document.createElement('li');
      li.innerHTML = `${project.name} <button onclick="deleteProject('${project.id}')">Delete</button>`;
      projectList.appendChild(li);
    });

  document.getElementById('project-name').value = '';
}

function deleteProject(id) {
  fetch(`http://localhost:3000/api/projects/${id}`, {
    method: 'DELETE'
  })
    .then(response => response.json())
    .then(() => {
      loadProjects();
    });
}
