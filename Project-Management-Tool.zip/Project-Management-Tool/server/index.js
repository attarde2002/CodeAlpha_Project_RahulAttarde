const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(cors());
app.use(express.static('public'));

const dataFilePath = './server/data.json';

// Load projects from file
const loadProjects = () => {
  const data = fs.readFileSync(dataFilePath);
  return JSON.parse(data);
};

// Save projects to file
const saveProjects = (projects) => {
  fs.writeFileSync(dataFilePath, JSON.stringify(projects, null, 2));
};

// Get all projects
app.get('/api/projects', (req, res) => {
  const projects = loadProjects();
  res.json(projects);
});

// Add a new project
app.post('/api/projects', (req, res) => {
  const projects = loadProjects();
  const newProject = req.body;
  projects.push(newProject);
  saveProjects(projects);
  res.json(newProject);
});

// Delete a project
app.delete('/api/projects/:id', (req, res) => {
  let projects = loadProjects();
  const projectId = req.params.id;
  projects = projects.filter((project) => project.id !== projectId);
  saveProjects(projects);
  res.json({ id: projectId });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
